import { Component } from '@angular/core';
import { CampaignsService } from '../campaigns.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  companys:any=[];

  
  constructor(private campService: CampaignsService,private router:Router) { }
  
  ngOnInit(): void {
    this.campService.getData().subscribe((data)=>{
      this.companys= data.slice(0, 3); // Display only first three records
      console.log(this.companys);
    })
  } 

  loadAllRecords() {
    // Fetch all records from backend API
    this.campService.getData().subscribe((data)=>{
      // Redirect to resource page
      this.router.navigate(['/resources']);
      });
  }

  
  navigateToDetails(whitepaperHeading: string, id: number): void {
    // Replace spaces with hyphens
  const formattedHeading = whitepaperHeading.trim().replace(/\s+/g, '-');
  
  // Navigate to details component with formattedHeading and ID
  this.router.navigate(['/Resources', formattedHeading], { state: { id: id } });
  }
}
