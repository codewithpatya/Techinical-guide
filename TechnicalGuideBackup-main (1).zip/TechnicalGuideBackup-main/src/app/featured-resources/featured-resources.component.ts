import { Component } from '@angular/core';
import { CampaignsService } from '../campaigns.service';
import { Router } from '@angular/router';
import { MetaTagService } from '../meta-tag.service';

@Component({
  selector: 'app-featured-resources',
  templateUrl: './featured-resources.component.html',
  styleUrls: ['./featured-resources.component.css']
})
export class FeaturedResourcesComponent {

  searchText: any;

  companys: any[] = [];
  pagedItems: any[] = []; // Array to hold the items to display on the current page
  pageSize: number = 15; // Number of items per page
  currentPage: number = 1; // Current page number
  totalItems: number = 0; // Total number of items

  dataAvailable: boolean = false; // Flag to indicate if data is available

  constructor(private campService: CampaignsService, private router: Router,private metaTagService:MetaTagService) {}

  ngOnInit(): void {
    this.loadAllData();

    this.metaTagService.updateMetaTags('Resources | Technical Guide', 'Discover Our Top Resources', 'resources,featured resources, technical guide');
  }

  loadAllData(): void {
    this.campService.getData().subscribe((data) => {
      this.totalItems = data.length;
      this.companys = data;
      this.dataAvailable = this.companys.length > 0; // Set the flag based on data availability
      this.loadPage(this.currentPage);
    });
  }

  loadPage(page: number): void {
    const startIndex = (page - 1) * this.pageSize;
    this.pagedItems = this.companys.slice(startIndex, startIndex + this.pageSize);
  }

  // navigateToDetails(id: number): void {
  //   this.router.navigate(['/Resources', id]); // Navigate to details component with ID
  // }

  navigateToDetails(whitepaperHeading: string, id: number): void {
    // Replace spaces with hyphens
  const formattedHeading = whitepaperHeading.trim().replace(/\s+/g, '-');
  
  // Navigate to details component with formattedHeading and ID
  this.router.navigate(['/Resources', formattedHeading], { state: { id: id } });
  }

  pageChanged(event: any): void {
    this.currentPage = event;
    this.loadPage(this.currentPage); // Fetch items for the current page
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.pageChanged(this.currentPage - 1); // Navigate to the previous page
    }
  }

  nextPage(): void {
    if (this.currentPage < Math.ceil(this.totalItems / this.pageSize)) {
      this.pageChanged(this.currentPage + 1); // Navigate to the next page
    }
  }


  // Method to scroll to the element with class 'arrow'
  scrollToArrow() {
    const element = document.querySelector('.arrow');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }

  
  
}

