import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { MetaTagService } from '../meta-tag.service';

@Component({
  selector: 'app-jobtitles',
  templateUrl: './jobtitles.component.html',
  styleUrls: ['./jobtitles.component.css']
})
export class JobtitlesComponent {

  constructor(private metaTagService:MetaTagService) { }

  searchText: any;

  jobtitles:any = [];

  ngOnInit(): void {
    this.metaTagService.updateMetaTags('Job Functions | Technical Guide', 'Search for Job Functions..More than 10000+ resources for you', 'Job Functions, technical guide');
  }

  cards = [
   
    {titles:"Business", title: 'Business', img: 'meeting.png'},
    {titles:"Medical & Health",title:'Medical&-Health',img:'medical-team.png'},
    {titles:"Finance", title:'Finance',   img: 'economics.png' },
    {titles:"Operations",title:'Operations',    img:'operation.png'},
    {titles:"Information Technology", title:'Information-Technology', img:'software-developer.png'},
    {titles:"Legal",title:'Legal',      img:'compliance.png'},


    // {titles:"Education", title:'Education', img: 'classroom.png' },
    // {titles:"Engineer", title:'Engineer',  img: 'engineers.png' },

    // {titles:"Design", title:'Design',    img: 'graphic-design.png' },
   
    // 
    // {titles:"Marketing",title:'Marketing',    img:'social-media.png'},
    // {titles:"Sales",title:'Sales',img:'sales.png'},

   
    // {titles:"Support",title:'Support',img:'customer-service.png'},
    // {titles:"Research",title:'Research',img:'strategy-development.png'}, 
    // {titles:"Purchasing",title:'Purchasing',img:'customer.png'},

    // {titles:"Consulting",title:'Consulting',img:'factory.png'},
    // {titles:"Administrative", title:'Administrative',   img: 'ceo.png' },
    // {titles:"Entrepreneurship",title:'Entrepreneurship',img:'entrepreneur.png'},
    // {titles:"Real Estate",title:'Real-Estate',img:'building.png'},


    
    // {titles:"Human Resources", title:'Human-Resources',  img: 'hr.png' },
    
    // {titles:"Accounting/ Auditing", title: 'Accounting-Or-Auditing', img: 'customer.png' },

    // {titles:"Quality Assurance",title:'Quality-Assurance',img:'tester.png'},
    // {titles:"Project Management",title:'Project-Management',img:'project-manager.png'},
    // {titles:"Product Management",title:'Product-Management',img:'product.png'},
    // {titles:"Writing and Editing",title:'Writing-And-Editing',img:'writing.png'},
    // {titles:"Media-And-Communication",title:'Media-And-Communication',img:'partners.png'},
    // {titles:"Community-And-Social-Services",title:'Community-And-Social-Services',img:'social-services.png'},

  ];


  
}

