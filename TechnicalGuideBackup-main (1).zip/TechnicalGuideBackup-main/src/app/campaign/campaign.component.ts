import { Component,OnInit} from '@angular/core';
import { HttpClient} from '@angular/common/http'
import { FormBuilder, FormGroup } from '@angular/forms';
import { CampaignsService } from '../campaigns.service';



@Component({
  selector: 'app-campaign',
  templateUrl: './campaign.component.html',
  styleUrls: ['./campaign.component.css']
})
export class CampaignComponent {

uploadForm: FormGroup;

constructor(private fb: FormBuilder, private fileUploadService: CampaignsService) {
  this.uploadForm = this.fb.group({
    summarizedContent: [''],
    campaignId: [''],
    campaignName: [''],
    uniqueId: [''],
    whitepaperHeading: [''],
    imagedomain: [''],
    wpimg: [''],
    Categories: [''],
    jobtitle: [''],
    pdfUrl: [''],
    privacylink: ['']
  });
}

onSubmit() {
  this.fileUploadService.uploadFile(this.uploadForm.value).subscribe(
    response => {
      alert("Whitepaper Submitted Sucessfully!")
      console.log('File uploaded successfully', response);

      // Reset the form after successful submission
      this.uploadForm.reset();

    },
    error => {
      console.error('Error uploading file', error);
    }
  );
}

}
