import { Component, OnInit } from '@angular/core';
import { MetaTagService } from '../meta-tag.service';

@Component({
  selector: 'app-technology',
  templateUrl: './technology.component.html',
  styleUrls: ['./technology.component.css']
})
export class TechnologyComponent implements OnInit {

  constructor(private metaTagService:MetaTagService) {}

  ngOnInit(): void {
    this.metaTagService.updateMetaTags('Technologies | Technical Guide', 'Search for Technologies..More than 10000+ resources for you', 'Technologies, technical guide');
  }

}
