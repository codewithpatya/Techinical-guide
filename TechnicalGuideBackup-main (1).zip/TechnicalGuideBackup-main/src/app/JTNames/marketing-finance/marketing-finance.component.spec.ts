import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketingFinanceComponent } from './marketing-finance.component';

describe('MarketingFinanceComponent', () => {
  let component: MarketingFinanceComponent;
  let fixture: ComponentFixture<MarketingFinanceComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MarketingFinanceComponent]
    });
    fixture = TestBed.createComponent(MarketingFinanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
