import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WritingandEditingComponent } from './writingand-editing.component';

describe('WritingandEditingComponent', () => {
  let component: WritingandEditingComponent;
  let fixture: ComponentFixture<WritingandEditingComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [WritingandEditingComponent]
    });
    fixture = TestBed.createComponent(WritingandEditingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
