import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-purchasing',
  templateUrl: './purchasing.component.html',
  styleUrls: ['./purchasing.component.css']
})
export class PurchasingComponent {

  searchText:any;

  catData: any ;
  
  total: any;
  dataAvailable: boolean = false;

  constructor(private http: HttpClient,private router:Router) { }

  ngOnInit(): void {
    this.fetchDataByCampaignName('purchasing');
  }

  fetchDataByCampaignName(jobtitle: string): void {
    
    this.http.get<any[]>('https://addwhitepaper.onrender.com/data/jt/' + encodeURIComponent(jobtitle))
      .subscribe(
        (data:any) => {
          this.catData = data.data;
          console.log('jobtitle:', this.catData);
          this.dataAvailable = this.catData.length > 0; // Set the flag based on data availability
          this.total = data.total;
          console.log("total data:",this.total);
        },
        error => {
          console.error('Error fetching data:', error);
        }
      );
  }

  navigateToDetails(id: number) {
    this.router.navigate(['/Resources', id]); // Navigate to details component with ID
    this.catData = []
  }

  

}
