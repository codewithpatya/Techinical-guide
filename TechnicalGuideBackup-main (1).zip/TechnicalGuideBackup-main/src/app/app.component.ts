import { Component,OnInit } from '@angular/core';
import { NavigationEnd, Event,Router, ActivatedRoute } from '@angular/router';
import { CampaignsService } from './campaigns.service';
import { filter } from 'rxjs/operators';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {

  title = 'Web'; 

  id: any;
  
  constructor(private route: ActivatedRoute,private router: Router, private faviconService: CampaignsService, private dataService: CampaignsService) {}

  ngOnInit() {
    this.id = this.route.snapshot.paramMap.get('id');

    console.log(this.id,"the id is:");

    this.router.events.pipe(
      filter((event: Event): event is NavigationEnd => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      const url = this.router.url;
      const id = this.extractIdFromUrl(url);

      if (id) {
        this.fetchDataById(id).then(data => {
          if (data.faviconurl) {
            this.faviconService.setFavicon(data.faviconurl);
          }
          else {
            this.faviconService.setDefaultFavicon();
          }
          if (data.campaignName) {
            this.faviconService.setTitle(data.campaignName);
          } else {
            this.faviconService.setTitle('Technical Guide');
          }
        }).catch(error => {
          console.error('Error fetching data:', error);
          this.faviconService.setDefaultFavicon();
        });
      }else{
        this.faviconService.setDefaultFavicon();
      }
    });
    this.faviconService.setDefaultFavicon();
  }

  extractIdFromUrl(url: string): string | null {
    const match = url.match(/\/data\/(\w+)/);
    return match ? match[1] : null;
  }

  async fetchDataById(id: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.dataService.getDataById(id).subscribe(
        data => resolve(data),
        error => reject(error)
      );
    });
  }
}
