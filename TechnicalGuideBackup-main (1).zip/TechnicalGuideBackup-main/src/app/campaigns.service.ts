import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import axios from 'axios';

@Injectable({
  providedIn: 'root'
})
export class CampaignsService {
  
  
  constructor(private http: HttpClient) {}

  private baseUrl = 'https://addwhitepaper.onrender.com';

        // https://addwhitepaper.onrender.com;
        
        //http://localhost:3000

  getData(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/data`)
  }
 
 
  uploadFile(formData: FormData): Observable<any> {
    return this.http.post('https://addwhitepaper.onrender.com/submit', formData);  // http://localhost:3000
  }

  downloadFile(fileId: any): Observable<Blob> {
    return this.http.get(`https://addwhitepaper.onrender.com/data/download/${fileId}?timestamp=${new Date().getTime()}`, { responseType: 'blob' });
  }

  getDataById(id: any): Observable<any> {  
    return this.http.get(`${this.baseUrl}/data/${id}`);
  }

 private wpurl = 'http://localhost:3000/data/whitepaper';
  // BY WHITEPAPER
  getDataBywp(whitepaperHeading: any): Observable<any> {  
    return this.http.get(`${this.wpurl}/${whitepaperHeading}`);
  }

  private url = 'http://localhost:5000/DownloadPaper'; // Replace with your API endpoint
  submitData(formData: FormData): Observable<any> {
    return this.http.post(`${this.url}`,formData);
  }

  private total: number = 0;

  setTotal(total: number): void {
    this.total = total;
  }

  getTotal(): number {
    return this.total;
  }

  setFavicon(url: string) {
    const link: HTMLLinkElement = document.querySelector("link[rel*='icon']") || document.createElement('link');
    link.type = 'image/x-icon';
    link.rel = 'shortcut icon';
    link.href = url;
    link.setAttribute('style', 'object-fit: none;' );
    document.getElementsByTagName('head')[0].appendChild(link);
  }


  setDefaultFavicon() {
    this.setFavicon('/assets/images/logo.JPG'); // Path to your default favicon
    this.setTitle('Technical Guide'); // Set your default title here
  }

  setTitle(title: string) {
    document.title = title;
  }



  private Url = 'https://addwhitepaper.onrender.com/data/campaign'; // Update this UR

  getDataByCampaignName(campaignName: string): Observable<any> {
    return this.http.get<any>(`${this.Url}/${campaignName}`)
  }
}


