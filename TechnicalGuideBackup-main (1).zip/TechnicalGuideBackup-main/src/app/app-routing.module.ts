import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';

import { CompaniesComponent } from './companies/companies.component';
import { CategoriesComponent } from './categories/categories.component';


import { ContactusComponent } from './contactus/contactus.component';


import { FeaturedResourcesComponent } from './featured-resources/featured-resources.component';
import { CampaignComponent } from './campaign/campaign.component';


import { ViewResourceComponent } from './view-resource/view-resource.component';
import { AerospaceComponent } from './CatNames/aerospace/aerospace.component';
import { JobtitlesComponent } from './jobtitles/jobtitles.component';
import { UpCloudComponent } from './CNames/up-cloud/up-cloud.component';
import { InformaticaComponent } from './CNames/informatica/informatica.component';
import { HCLTechComponent } from './CNames/h-cltech/h-cltech.component';
import { BusinessComponent } from './JTNames/business/business.component';

import { DesignComponent } from './JTNames/design/design.component';
import { EducationComponent } from './JTNames/education/education.component';
import { EngineerComponent } from './JTNames/engineer/engineer.component';
import { FinanceComponent } from './JTNames/finance/finance.component';
import { FounderComponent } from './JTNames/founder/founder.component';
import { HRComponent } from './JTNames/hr/hr.component';
import { ITComponent } from './JTNames/it/it.component';
import { LawComponent } from './JTNames/law/law.component';
import { LegalComponent } from './JTNames/legal/legal.component';
import { ManufacturingComponent } from './JTNames/manufacturing/manufacturing.component';
import { MarketingComponent } from './JTNames/marketing/marketing.component';
import { MedicalComponent } from './JTNames/medical/medical.component';
import { OperationComponent } from './JTNames/operation/operation.component';
import { OwnerComponent } from './JTNames/owner/owner.component';
import { PartnerComponent } from './JTNames/partner/partner.component';
import { SalesComponent } from './JTNames/sales/sales.component';
import { MarketingFinanceComponent } from './JTNames/marketing-finance/marketing-finance.component';
import { SoftwareITComponent } from './CatNames/software-it/software-it.component';
import { AgricultureMiningComponent } from './CatNames/agriculture-mining/agriculture-mining.component';
import { BusinessservicesComponent } from './CatNames/businessservices/businessservices.component';
import { ComputersComponent } from './CatNames/computers/computers.component';
import { ConstructionRealEstateComponent } from './CatNames/construction-real-estate/construction-real-estate.component';
import { EnergyRawMaterialsComponent } from './CatNames/energy-raw-materials/energy-raw-materials.component';
import { GovernmentComponent } from './CatNames/government/government.component';
import { FoodComponent } from './CatNames/food/food.component';
import { HealthcareComponent } from './CatNames/healthcare/healthcare.component';
import { WholesaleComponent } from './CatNames/wholesale/wholesale.component';
import { TravelComponent } from './CatNames/travel/travel.component';
import { TransportationComponent } from './CatNames/transportation/transportation.component';
import { TelecommunicationsComponent } from './CatNames/telecommunications/telecommunications.component';
import { RetailComponent } from './CatNames/retail/retail.component';
import { MediaEntertainmentComponent } from './CatNames/media-entertainment/media-entertainment.component';
import { MarketingAdvertiComponent } from './CatNames/marketing-adverti/marketing-adverti.component';
import { NonProfitComponent } from './CatNames/non-profit/non-profit.component';
import { EduComponent } from './CatNames/edu/edu.component';
import { FinaComponent } from './CatNames/fina/fina.component';
import { ManufComponent } from './CatNames/manuf/manuf.component';
import { SalesforceComponent } from './CNames/salesforce/salesforce.component';

import { MotorolaComponent } from './CNames/motorola/motorola.component';

import { ThermoFisherComponent } from './CNames/thermo-fisher/thermo-fisher.component';

import { LeaglsComponent } from './CatNames/leagls/leagls.component';
import { CustomerComponent } from './JTNames/customer/customer.component';
import { RealEstateComponent } from './JTNames/real-estate/real-estate.component';
import { QualityAssuranceComponent } from './JTNames/quality-assurance/quality-assurance.component';
import { PurchasingComponent } from './JTNames/purchasing/purchasing.component';
import { ProjectManagementComponent } from './JTNames/project-management/project-management.component';
import { ProductManagementComponent } from './JTNames/product-management/product-management.component';
import { SupportComponent } from './JTNames/support/support.component';
import { WritingandEditingComponent } from './JTNames/writingand-editing/writingand-editing.component';
import { PrivacypolicyComponent } from './privacypolicy/privacypolicy.component';
import { UseraggrimentComponent } from './useraggriment/useraggriment.component';
import { TechnologyComponent } from './technology/technology.component';
import { AllcompaniesComponent } from './allcompanies/allcompanies.component';

const routes: Routes = [

  {path:'',pathMatch:'full',redirectTo:'home'},
  {path:'home',component:HomeComponent},

  {path:'contact',component:ContactusComponent},

  {path:'resources',component:FeaturedResourcesComponent},
  {path:'camp',component:CampaignComponent},
  {path: 'Resources/:whitepaperHeading', component:ViewResourceComponent},

  {path: 'Recent-Resources/:campaignName',component:AllcompaniesComponent},

  // start company names
  {path:'companies',component:CompaniesComponent},
  {path:'upcloud',component:UpCloudComponent},
  {path:'informatica',component:InformaticaComponent},
  {path:'hcltech',component:HCLTechComponent},
  {path:'salesforce',component:SalesforceComponent},
 

 
  {path:'motorola',component:MotorolaComponent},
  {path:'salesforce',component:SalesforceComponent},
  
  {path:'thermofisher',component:ThermoFisherComponent},

  // end company names

  // start Industries
  {path:'Industries',component:CategoriesComponent},
  {path:'aerospace&_aviation',component:AerospaceComponent},
  {path:'software,internet&_technology',component:SoftwareITComponent},
  {path:'business_services',component:BusinessservicesComponent},
  {path:'computers&_computers',component:ComputersComponent},
  {path:'agriculture&_mining',component:AgricultureMiningComponent},
  {path:'construction&_real_estate',component:ConstructionRealEstateComponent},
  {path:'educations', component:EduComponent},
  {path:'energy,raw_materials&_utilities',component:EnergyRawMaterialsComponent},
  {path:'financial_services',component:FinaComponent},
  {path:'government',component:GovernmentComponent},
  {path:'legals',component:LeaglsComponent},
  {path:'manufacturings',component:ManufComponent},
  {path:'marketing,advertising&_public_relations',component:MarketingAdvertiComponent},
  {path:'media,entertainment&_publishing',component:MediaEntertainmentComponent},
  {path:'non-profit',component:NonProfitComponent},
  {path:'retail',component:RetailComponent},
  {path:'telecommunications',component:TelecommunicationsComponent},
  {path:'transportation',component:TransportationComponent},
  {path:'travel_hotel_restaurant&_recreation',component:TravelComponent},
  {path:'wholesale&_distribution',component:WholesaleComponent},
  {path:'healthcare,_pharmaceuticals_and_biotech',component:HealthcareComponent},
  {path:'food&_beverage',component:FoodComponent},
  // end categories

  // start 
  {path:'Job-Function',component:JobtitlesComponent},
  {path:'design',component:DesignComponent},
  {path:'business',component:BusinessComponent},
  {path:'education',component:EducationComponent},
  {path:'engineer',component:EngineerComponent},
  {path:'finance',component:FinanceComponent},
  {path:'medical&-health',component:MedicalComponent},
  {path:'human-resources',component:HRComponent},
  {path:'information-technology',component:ITComponent},
  {path:'legal',component:LegalComponent},
  {path:'marketing',component:MarketingComponent},
  {path:'sales',component:SalesComponent},
  {path:'operations',component:OperationComponent},
  
  {path:'accounting-or-auditing',component:CustomerComponent},
  {path:'administrative',component:FounderComponent},
  {path:'community-and-social-services',component:LawComponent},
  {path:'consulting',component:ManufacturingComponent},
  {path:'entrepreneurship',component:OwnerComponent},
  {path:'media-and-communication',component:PartnerComponent},
  {path:'research ',component:MarketingFinanceComponent},
  {path:'real-estate',component:RealEstateComponent},
  {path:'quality-assurance',component:QualityAssuranceComponent},
  {path:'purchasing',component:PurchasingComponent},
  {path:'project-management',component:ProjectManagementComponent},
  {path:'product-management',component:ProductManagementComponent},
  {path:'support',component:SupportComponent},
  {path:'writing-and-editing',component:WritingandEditingComponent},
  // end jobtitles

  // Technology
  {path:'Technology',component:TechnologyComponent},

  // footer
  {path:'privacy-policy',component:PrivacypolicyComponent},
  {path:'user-aggriment',component:UseraggrimentComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    initialNavigation: 'enabledBlocking'
})],
  exports: [RouterModule]
})

export class AppRoutingModule { }
