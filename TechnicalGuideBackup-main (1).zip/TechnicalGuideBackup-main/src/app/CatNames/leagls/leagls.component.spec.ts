import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeaglsComponent } from './leagls.component';

describe('LeaglsComponent', () => {
  let component: LeaglsComponent;
  let fixture: ComponentFixture<LeaglsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [LeaglsComponent]
    });
    fixture = TestBed.createComponent(LeaglsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
