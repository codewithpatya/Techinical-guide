import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SoftwareITComponent } from './software-it.component';

describe('SoftwareITComponent', () => {
  let component: SoftwareITComponent;
  let fixture: ComponentFixture<SoftwareITComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SoftwareITComponent]
    });
    fixture = TestBed.createComponent(SoftwareITComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
