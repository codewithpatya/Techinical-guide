import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgricultureMiningComponent } from './agriculture-mining.component';

describe('AgricultureMiningComponent', () => {
  let component: AgricultureMiningComponent;
  let fixture: ComponentFixture<AgricultureMiningComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AgricultureMiningComponent]
    });
    fixture = TestBed.createComponent(AgricultureMiningComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
