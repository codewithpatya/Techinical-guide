import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CampaignsService } from 'src/app/campaigns.service';

@Component({
  selector: 'app-manuf',
  templateUrl: './manuf.component.html',
  styleUrls: ['./manuf.component.css']
})
export class ManufComponent {

  
  searchText:any;

  catData: any ;

  total :any;
  
  dataAvailable: boolean = false;

  constructor(private http: HttpClient,private router:Router,private campservice:CampaignsService) { }

  ngOnInit(): void {
    this.fetchDataByCampaignName('Manufacturing');
  }

  fetchDataByCampaignName(Categories: string): void {
    
    this.http.get<any[]>('https://addwhitepaper.onrender.com/data/cat/' + encodeURIComponent(Categories))
      .subscribe(
        (data:any) => {
          this.catData = data.data;
          console.log('Categories:', this.catData);
          this.dataAvailable = this.catData.length > 0; // Set the flag based on data availability
          this.total = data.total
          console.log('total data:', this.total);
        },
        error => {
          console.error('Error fetching data:', error);
        }
      );
  }

  navigateToDetails(whitepaperHeading: string, id: number): void {
    // Replace spaces with hyphens
  const formattedHeading = whitepaperHeading.trim().replace(/\s+/g, '-');
  
  // Navigate to details component with formattedHeading and ID
  this.router.navigate(['/Resources', formattedHeading], { state: { id: id } });
  }

}
