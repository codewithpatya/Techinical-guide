import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManufComponent } from './manuf.component';

describe('ManufComponent', () => {
  let component: ManufComponent;
  let fixture: ComponentFixture<ManufComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ManufComponent]
    });
    fixture = TestBed.createComponent(ManufComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
