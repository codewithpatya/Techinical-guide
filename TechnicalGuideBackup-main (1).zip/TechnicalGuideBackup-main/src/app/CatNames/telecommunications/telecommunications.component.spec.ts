import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TelecommunicationsComponent } from './telecommunications.component';

describe('TelecommunicationsComponent', () => {
  let component: TelecommunicationsComponent;
  let fixture: ComponentFixture<TelecommunicationsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TelecommunicationsComponent]
    });
    fixture = TestBed.createComponent(TelecommunicationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
