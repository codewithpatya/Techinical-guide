import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessservicesComponent } from './businessservices.component';

describe('BusinessservicesComponent', () => {
  let component: BusinessservicesComponent;
  let fixture: ComponentFixture<BusinessservicesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BusinessservicesComponent]
    });
    fixture = TestBed.createComponent(BusinessservicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
