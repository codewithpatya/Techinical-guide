import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FinaComponent } from './fina.component';

describe('FinaComponent', () => {
  let component: FinaComponent;
  let fixture: ComponentFixture<FinaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FinaComponent]
    });
    fixture = TestBed.createComponent(FinaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
