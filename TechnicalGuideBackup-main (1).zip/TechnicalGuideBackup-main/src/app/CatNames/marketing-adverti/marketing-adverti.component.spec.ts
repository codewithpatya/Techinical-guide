import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketingAdvertiComponent } from './marketing-adverti.component';

describe('MarketingAdvertiComponent', () => {
  let component: MarketingAdvertiComponent;
  let fixture: ComponentFixture<MarketingAdvertiComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MarketingAdvertiComponent]
    });
    fixture = TestBed.createComponent(MarketingAdvertiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
