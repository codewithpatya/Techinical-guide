import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EnergyRawMaterialsComponent } from './energy-raw-materials.component';

describe('EnergyRawMaterialsComponent', () => {
  let component: EnergyRawMaterialsComponent;
  let fixture: ComponentFixture<EnergyRawMaterialsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EnergyRawMaterialsComponent]
    });
    fixture = TestBed.createComponent(EnergyRawMaterialsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
