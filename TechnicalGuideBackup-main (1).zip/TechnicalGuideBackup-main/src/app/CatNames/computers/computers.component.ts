import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-computers',
  templateUrl: './computers.component.html',
  styleUrls: ['./computers.component.css']
})
export class ComputersComponent {

  searchText:any;

  catData: any ;

  total:any
  
  dataAvailable: boolean = false;

  constructor(private http: HttpClient,private router:Router) { }

  ngOnInit(): void {
    this.fetchDataByCampaignName('Computers & Computers');
  }

  fetchDataByCampaignName(Categories: string): void {
    
    this.http.get<any[]>('https://addwhitepaper.onrender.com/data/cat/' + encodeURIComponent(Categories))
      .subscribe(
        (data:any) => {
          this.catData = data.data;
          console.log('Categories:', this.catData);
          this.dataAvailable = this.catData.length > 0; // Set the flag based on data availability
          this.total = data.total
          console.log("total data:",this.total);
          
        },
        error => {
          console.error('Error fetching data:', error);
        }
      );
  }

  navigateToDetails(whitepaperHeading: string, id: number): void {
    // Replace spaces with hyphens
  const formattedHeading = whitepaperHeading.trim().replace(/\s+/g, '-');
  
  // Navigate to details component with formattedHeading and ID
  this.router.navigate(['/Resources', formattedHeading], { state: { id: id } });
  }



}
