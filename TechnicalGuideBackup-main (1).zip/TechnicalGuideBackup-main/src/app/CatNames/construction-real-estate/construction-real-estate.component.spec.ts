import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConstructionRealEstateComponent } from './construction-real-estate.component';

describe('ConstructionRealEstateComponent', () => {
  let component: ConstructionRealEstateComponent;
  let fixture: ComponentFixture<ConstructionRealEstateComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ConstructionRealEstateComponent]
    });
    fixture = TestBed.createComponent(ConstructionRealEstateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
