import { Component, OnInit } from '@angular/core';
import { MetaTagService } from '../meta-tag.service';

@Component({
  selector: 'app-useraggriment',
  templateUrl: './useraggriment.component.html',
  styleUrls: ['./useraggriment.component.css']
})
export class UseraggrimentComponent implements OnInit {

  constructor(private metaTagService: MetaTagService) { }

  ngOnInit(): void {
    this.metaTagService.updateMetaTags('User Aggriment | Technical Guide', 'terms-of-use', 'terms of use & conditions, user aggriment');
  }

}
