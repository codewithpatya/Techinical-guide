import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UseraggrimentComponent } from './useraggriment.component';

describe('UseraggrimentComponent', () => {
  let component: UseraggrimentComponent;
  let fixture: ComponentFixture<UseraggrimentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UseraggrimentComponent]
    });
    fixture = TestBed.createComponent(UseraggrimentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
