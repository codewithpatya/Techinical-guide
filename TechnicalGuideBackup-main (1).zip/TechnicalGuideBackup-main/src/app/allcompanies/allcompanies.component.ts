import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CampaignsService } from '../campaigns.service';
import { HttpClient } from '@angular/common/http';
import { MetaTagService } from '../meta-tag.service';

@Component({
  selector: 'app-allcompanies',
  templateUrl: './allcompanies.component.html',
  styleUrls: ['./allcompanies.component.css']
})
export class AllcompaniesComponent {
  company: any ;
  inputFieldValue: any;
  campaignData: any ;
  searchText:any;
  
  dataAvailable: boolean = false;

  

   
  constructor(private route: ActivatedRoute, 
    private dataService: CampaignsService,
    private http: HttpClient,private router:Router,private metaTagService: MetaTagService, private faviconService: CampaignsService,) { }


    ngOnInit() {
      this.metaTagService.updateMetaTags('Recent-Resources | Technical Guide', 'Recent Resources', 'Recent Resources, Resources');
      
  this.company = this.route.snapshot.paramMap.get('campaignName');

  this.fetchDataByCampaignName(this.company); 
  this.faviconService.setTitle(`Recent-Resource: ${this.company}`);

  console.log(this.company,"the company is:");
  
  this.route.paramMap.subscribe(params => {
    const idParam = params.get('id');
    if (idParam) {
      this.company = idParam;
      this.inputFieldValue = idParam; // Direct assignment since both are strings
      this.faviconService.setTitle(`Recent-Resource: ${this.company}`);
     
    }
  });

}

fetchDataByCampaignName(campaignName: string): void {
    
  this.http.get<any[]>('https://addwhitepaper.onrender.com/data/campaign/' + encodeURIComponent(campaignName))
    .subscribe(
      data => {
        this.campaignData = data;
        console.log('Campaign data:', this.campaignData);
        this.dataAvailable = this.campaignData.length > 0; // Set the flag based on data availability
        
      },
      error => {
        console.error('Error fetching data:', error);
      }
    );
}

navigateToDetails(whitepaperHeading: string, id: number): void {
  // Replace spaces with hyphens
const formattedHeading = whitepaperHeading.trim().replace(/\s+/g, '-');

// Navigate to details component with formattedHeading and ID
this.router.navigate(['/Resources', formattedHeading], { state: { id: id } });
}



}
