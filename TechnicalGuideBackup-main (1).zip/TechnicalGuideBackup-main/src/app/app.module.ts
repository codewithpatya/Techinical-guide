import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { NavComponent } from './nav/nav.component';

import { CompaniesComponent } from './companies/companies.component';
import { CategoriesComponent } from './categories/categories.component';

import { FooterComponent } from './footer/footer.component';
import { ContactusComponent } from './contactus/contactus.component';

import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule} from '@angular/forms'

import { HttpClientModule } from '@angular/common/http';


import { FeaturedResourcesComponent } from './featured-resources/featured-resources.component';

import {NgxPaginationModule} from 'ngx-pagination';
import { CampaignComponent } from './campaign/campaign.component';


import { AerospaceComponent } from './CatNames/aerospace/aerospace.component';
import { ViewResourceComponent } from './view-resource/view-resource.component';

import { SearchFilterPipe } from './search-filter.pipe';
import { JobtitlesComponent } from './jobtitles/jobtitles.component';
import { FilterPipe } from './filter.pipe';
import { UpCloudComponent } from './CNames/up-cloud/up-cloud.component';
import { InformaticaComponent } from './CNames/informatica/informatica.component';
import { HCLTechComponent } from './CNames/h-cltech/h-cltech.component';
import { BusinessComponent } from './JTNames/business/business.component';
import { CustomerComponent } from './JTNames/customer/customer.component';
import { DesignComponent } from './JTNames/design/design.component';
import { EducationComponent } from './JTNames/education/education.component';
import { EngineerComponent } from './JTNames/engineer/engineer.component';
import { FinanceComponent } from './JTNames/finance/finance.component';
import { FounderComponent } from './JTNames/founder/founder.component';
import { LawComponent } from './JTNames/law/law.component';
import { LegalComponent } from './JTNames/legal/legal.component';
import { ManufacturingComponent } from './JTNames/manufacturing/manufacturing.component';
import { MarketingComponent } from './JTNames/marketing/marketing.component';
import { OperationComponent } from './JTNames/operation/operation.component';
import { OwnerComponent } from './JTNames/owner/owner.component';
import { PartnerComponent } from './JTNames/partner/partner.component';
import { SalesComponent } from './JTNames/sales/sales.component';
import { MedicalComponent } from './JTNames/medical/medical.component';
import { HRComponent } from './JTNames/hr/hr.component';
import { ITComponent } from './JTNames/it/it.component';
import { MarketingFinanceComponent } from './JTNames/marketing-finance/marketing-finance.component';
import { SoftwareITComponent } from './CatNames/software-it/software-it.component';
import { BusinessservicesComponent } from './CatNames/businessservices/businessservices.component';
import { ComputersComponent } from './CatNames/computers/computers.component';
import { ConstructionRealEstateComponent } from './CatNames/construction-real-estate/construction-real-estate.component';
import { EnergyRawMaterialsComponent } from './CatNames/energy-raw-materials/energy-raw-materials.component';
import { GovernmentComponent } from './CatNames/government/government.component';
import { MarketingAdvertiComponent } from './CatNames/marketing-adverti/marketing-adverti.component';
import { MediaEntertainmentComponent } from './CatNames/media-entertainment/media-entertainment.component';
import { NonProfitComponent } from './CatNames/non-profit/non-profit.component';
import { RetailComponent } from './CatNames/retail/retail.component';
import { TelecommunicationsComponent } from './CatNames/telecommunications/telecommunications.component';
import { TransportationComponent } from './CatNames/transportation/transportation.component';
import { TravelComponent } from './CatNames/travel/travel.component';
import { WholesaleComponent } from './CatNames/wholesale/wholesale.component';
import { HealthcareComponent } from './CatNames/healthcare/healthcare.component';
import { FoodComponent } from './CatNames/food/food.component';
import { AgricultureMiningComponent } from './CatNames/agriculture-mining/agriculture-mining.component';
import { EduComponent } from './CatNames/edu/edu.component';
import { ManufComponent } from './CatNames/manuf/manuf.component';
import { FinaComponent } from './CatNames/fina/fina.component';
import { LeaglsComponent } from './CatNames/leagls/leagls.component';
import { SalesforceComponent } from './CNames/salesforce/salesforce.component';

import { MotorolaComponent } from './CNames/motorola/motorola.component';

import { ThermoFisherComponent } from './CNames/thermo-fisher/thermo-fisher.component';

import { NgxCaptchaModule, ReCaptchaType } from 'ngx-captcha';
import { RealEstateComponent } from './JTNames/real-estate/real-estate.component';
import { QualityAssuranceComponent } from './JTNames/quality-assurance/quality-assurance.component';
import { ProjectManagementComponent } from './JTNames/project-management/project-management.component';
import { PurchasingComponent } from './JTNames/purchasing/purchasing.component';
import { ProductManagementComponent } from './JTNames/product-management/product-management.component';
import { SupportComponent } from './JTNames/support/support.component';
import { WritingandEditingComponent } from './JTNames/writingand-editing/writingand-editing.component';
import { PrivacypolicyComponent } from './privacypolicy/privacypolicy.component';
import { UseraggrimentComponent } from './useraggriment/useraggriment.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TechnologyComponent } from './technology/technology.component';
import { AllcompaniesComponent } from './allcompanies/allcompanies.component';






@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavComponent,
    CompaniesComponent,
    CategoriesComponent,
  
    FooterComponent,
    ContactusComponent,
    
    FeaturedResourcesComponent,
    CampaignComponent,
  
    
    AerospaceComponent,
    ViewResourceComponent,
    SearchFilterPipe,
    JobtitlesComponent,
    FilterPipe,
    UpCloudComponent,
    InformaticaComponent,
    HCLTechComponent,
    BusinessComponent,
    CustomerComponent,
    DesignComponent,
    EducationComponent,
    EngineerComponent,
    FinanceComponent,
    FounderComponent,
    LawComponent,
    LegalComponent,
    ManufacturingComponent,
    MarketingComponent,
    OperationComponent,
    OwnerComponent,
    PartnerComponent,
    SalesComponent,
    MedicalComponent,
    HRComponent,
    ITComponent,
    MarketingFinanceComponent,
    SoftwareITComponent,
    BusinessservicesComponent,
    ComputersComponent,
    ConstructionRealEstateComponent,
    EnergyRawMaterialsComponent,
    GovernmentComponent,
    MarketingAdvertiComponent,
    MediaEntertainmentComponent,
    NonProfitComponent,
    RetailComponent,
    TelecommunicationsComponent,
    TransportationComponent,
    TravelComponent,
    WholesaleComponent,
    HealthcareComponent,
    FoodComponent,
    AgricultureMiningComponent,
    EduComponent,
    ManufComponent,
    FinaComponent,
    LeaglsComponent,
    SalesforceComponent,
   
    
    MotorolaComponent,
    
    ThermoFisherComponent,
   
    RealEstateComponent,
    QualityAssuranceComponent,
    ProjectManagementComponent,
    PurchasingComponent,
    ProductManagementComponent,
    SupportComponent,
    WritingandEditingComponent,
    PrivacypolicyComponent,
    UseraggrimentComponent,
    TechnologyComponent,
    AllcompaniesComponent,
    
    
  ],
  imports: [

    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    NgxCaptchaModule,
    BrowserAnimationsModule,
   
  ],
  providers: [

    {
      provide: ReCaptchaType,
      useValue: 'explicit', // Use 'explicit' for the checkbox style
    },

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

