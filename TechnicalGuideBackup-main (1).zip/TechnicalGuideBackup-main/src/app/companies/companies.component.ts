import { Component } from '@angular/core';
import { CampaignsService } from '../campaigns.service';
import { HttpClient } from '@angular/common/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { Router } from '@angular/router';
import Swiper from 'swiper';
import { MetaTagService } from '../meta-tag.service';





@Component({
  selector: 'app-companies',
  templateUrl: './companies.component.html',
  styleUrls: ['./companies.component.css']
})
export class CompaniesComponent {

  showData: boolean = false;   //Variable to toggle div visibility
  
 companys:any=[];
  
 filteredCompanyNames: any;

 pagedItems: any[] = []; // Array to hold the items to display on the current page
 pageSize: number = 10; // Number of items per page
 currentPage: number = 1; // Current page number
 totalItems: number = 0; // Total number of items

  ngOnInit(): void {
    this.metaTagService.updateMetaTags('Companies | Technical Guide', 'Explore Our Extensive List of Top Companies', 'companies,featured companies, technical guide');
  }

 constructor(private campService: CampaignsService,private http: HttpClient, private router: Router,private metaTagService:MetaTagService) { }
  
  searchText: any;

 card = [
  { title: 'ThermoFisher',  img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1718167505/36d6378d-154b-4c5d-90c5-b58b8656be05.png'},
  { title: 'Informatica',  img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1717645818/080bb8ab-f960-40a4-9095-67e04bfb8abd.png' },
  { title: 'UpCloud',   img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1717645651/846751a9-24a6-456d-9a59-9d76ba7128ba.png'},
  { title: 'Salesforce',  img: 'https://logo.clearbit.com/Salesforce.com'},
  { title: 'Motorola',  img: 'https://logo.clearbit.com/Motorola.com'},
  { title: 'HCLTech',     img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1720503006/95a2927a-4d2a-4c9c-9bb8-d6dd8c186a2c_3_d4f5km.png' },
  ];

  cards = [
  { title: 'A10Networks',   img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1720505494/A10_networks_abzo0t.png'},
  { title: 'Alteryx',   img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1720505641/2560px-Alteryx_logo.svg_xlt9wf.png'},
  { title: 'ezCater',     img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1718169526/52c40e92-4498-443d-9251-b49ccaf5f178.png'},
  { title: 'Fortinet',  img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1718169668/a84558ea-89fb-47cd-b8a4-91c434069189.png'},
  { title: 'Service Express',  img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1720505110/service-express_owler_20220913_130222_original_k4gykz.jpg'},
  { title: 'UNIT4',  img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1720504917/unit4_osh29u.png'},
  { title: 'UpCloud',   img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1717645651/846751a9-24a6-456d-9a59-9d76ba7128ba.png'},
  { title: 'Informatica',  img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1717645818/080bb8ab-f960-40a4-9095-67e04bfb8abd.png' },
  { title: 'HCLTech',     img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1720586618/HCL-logo_ilstdd.png' },
  { title: 'Salesforce',  img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1720502369/Salesforce-logo_ss692p.png'},
  { title: 'Motorola',  img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1720506717/wp2536745_pei3jy.png'},
  { title: 'Thermofisher',  img: 'https://res.cloudinary.com/dmx791wm9/image/upload/v1718167505/36d6378d-154b-4c5d-90c5-b58b8656be05.png'},  
];


// currentPage = 1;
cardsPerPage = 12;


// Function to handle page change event
pageChanged(event: any): void {
  this.currentPage = event;

}


get paginatedCards() {
  const startIndex = (this.currentPage - 1) * this.cardsPerPage;
  return this.cards.slice(startIndex, startIndex + this.cardsPerPage);
}

get totalPages() {
  return Math.ceil(this.cards.length / this.cardsPerPage);
}

changePage(page: number) {
  if (page > 0 && page <= this.totalPages) {
    this.currentPage = page;
  }
}

prevPage() {
  if (this.currentPage > 1) {
    this.currentPage--;
  }
}

nextPage() {
  if (this.currentPage < this.totalPages) {
    this.currentPage++;
  }
}

  campaignNames: any = [];

  navigateToDetails(campaignName: number): void {
    this.router.navigate(['/Recent-Resources', campaignName]); // Navigate to details component with ID
  }

  loadAllData(): void {
    this.campService.getData().subscribe((data) => {
      this.totalItems = data.length;
      this.companys = data;
    });
  }

  

}




 



