import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CampaignsService } from '../campaigns.service';
import { MetaTagService } from '../meta-tag.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {

  searchText: any = '';

  constructor(private campservice: CampaignsService,private http:HttpClient,private metaTagService:MetaTagService) {}
  
  ngOnInit(): void {
    this.metaTagService.updateMetaTags('Industries | Technical Guide', 'Search for Industries..More than 10000+ resources for you', 'Industries, technical guide');
    this.AerospaceAviation()
    this.AgricultureMining()
    this.BusinessServices()
    this.ComputersComputers()
    this.ConstructionRealEstate()
    this.Education()
    this.EnergyRawMaterialsUtilities()
    this.Finance()
    this.Government()
    this.Legal()
    this.Manufacturing()
    this.MarketingAdvertisingPublicRelations()
    this.MediaEntertainmentPublishing()
    this.NonProfit()
    this.Retail()
    this.SoftwareInternetAndTechnology()
    this.Telecommunications()
    this.Transportation()
    this.TravelHotelRestaurantAndRecreation()
    this.WholesaleDistribution()
    this.HealthcarePharmaceuticalsAndBiotech()
    this.FoodBeverage()
  }

  cards = [
    {title: 'Aerospace&_Aviation',img:'https://test.datagateway.in/images/category/areospace.jpg'},
    {title: 'Agriculture&_Mining',img:'https://test.datagateway.in/images/category/agri.jpg'},
    {title: 'Business_Services',img:'https://test.datagateway.in/images/category/ctg-1.jpg'},
    {title: 'Computers&_Computers',img:'https://test.datagateway.in/images/category/comp.jpg'},
    {title: 'Construction&_Real_Estate',img:'https://test.datagateway.in/images/category/realestate.jpg'},
    {title: 'Educations',img:'https://test.datagateway.in/images/category/education.jpg',rout:'Edu'},
    {titles:"Energy,Raw Materials & Utilities",title: 'Energy,Raw_Materials&_Utilities',img:'https://test.datagateway.in/images/category/energy.jpg'},
    {title: 'Financial_Services',img:'https://test.datagateway.in/images/category/finance.jpg'},
    {title: 'Government',img:'https://test.datagateway.in/images/category/govt.jpg'},
    {title: 'Legals',img:'https://test.datagateway.in/images/category/legal.jpg'},
    {title: 'Manufacturings',img:'https://test.datagateway.in/images/category/manu.jpg'},
    {title: 'Marketing,Advertising&_Public_Relations',img:'https://test.datagateway.in/images/category/market.jpeg'},
    {titles:"Media,Entertainment & Publishing",title: 'Media,Entertainment&_Publishing',img:'https://test.datagateway.in/images/category/market.jpeg'},
    {title: 'Non-Profit',img:'https://test.datagateway.in/images/category/non-pro.jpg'},
    {title: 'Retail',img:'https://test.datagateway.in/images/category/retail.jpg'},
    {title: 'Software,Internet&_Technology',img:'https://test.datagateway.in/images/category/software.jpg'},
    {title: 'Telecommunications',img:'https://test.datagateway.in/images/category/telecomm.jpg'},
    {titles:"Transportation",title: 'Transportation',img:'https://test.datagateway.in/images/category/transport.jpg'},
    {titles:"Travel Hotel Restaurant & Recreation",title: 'Travel_Hotel_Restaurant&_Recreation',img:'https://test.datagateway.in/images/category/travel.jpg'},
    {titles:"Wholesale& Distribution",title: 'Wholesale&_Distribution',img:'https://test.datagateway.in/images/category/whole.jpg'},
    {titles:"Healthcare, Pharmaceuticals And Biotech",title: 'Healthcare,_Pharmaceuticals_And_Biotech',img:'https://test.datagateway.in/images/category/health.jpg'},
    {titles:"Food & Beverage",title: 'Food&_Beverage',img:'https://test.datagateway.in/images/category/f&b.jpg'}
  ];

   // Aerospace & Aviation
  aerospace:any
  AerospaceAviation(){
  this.http.get('https://addwhitepaper.onrender.com/cat/Aerospace & Aviation').subscribe((data:any)=>{
    console.log(data);
    this.aerospace = data.total
    console.log("total data:",this.aerospace); 
  })
  }

  // Agriculture & Mining
  agriculture:any
  AgricultureMining(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Agriculture & Mining').subscribe((data:any)=>{
      console.log(data);
      this.agriculture = data.total
      console.log("total data:",this.agriculture); 
    })
  }
    
  // Computers & Computers
  computers:any
  ComputersComputers(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Computers & Computers').subscribe((data:any)=>{
      console.log(data);
      this.computers = data.total
      console.log("total data:",this.computers); 
    })
  }
  
  // Business Services
  business:any
  BusinessServices(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Business Services').subscribe((data:any)=>{
      console.log(data);
      this.business = data.total
      console.log("total data:",this.business); 
    })
  }

  // Construction & Real Estate
  construction:any
  ConstructionRealEstate(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Construction & Real Estate').subscribe((data:any)=>{
      console.log(data);
      this.construction = data.total
      console.log("total data:",this.construction); 
    })
  }

  // Education
  education:any
  Education(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Education').subscribe((data:any)=>{
      console.log(data);
      this.education = data.total
      console.log("total data:",this.education); 
    })
  }

  // Energy, Raw Materials & Utilities   
  energy:any
  EnergyRawMaterialsUtilities(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Energy, Raw Materials & Utilities').subscribe((data:any)=>{
      console.log(data);
      this.energy = data.total
      console.log("total data:",this.energy); 
    })
  } 
  
  // Finance
  finance:any
  Finance(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Finance').subscribe((data:any)=>{
      console.log(data);
      this.finance = data.total
      console.log("total data:",this.finance); 
    })
  }

  // Food & Beverage
  food:any
  FoodBeverage(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Food & Beverage').subscribe((data:any)=>{
      console.log(data);
      this.food = data.total
      console.log("total data:",this.food); 
    })
  }

  // Government
  government:any
  Government(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Government').subscribe((data:any)=>{
      console.log(data);
      this.government = data.total
      console.log("total data:",this.government); 
    })
  }

  // Healthcare, Pharmaceuticals and Biotech
  healthcare:any
  HealthcarePharmaceuticalsAndBiotech(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Healthcare, Pharmaceuticals and Biotech').subscribe((data:any)=>{
      console.log(data);
      this.healthcare = data.total
      console.log("total data:",this.healthcare); 
    })
  }

  // Legal
  legal:any
  Legal(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Legal').subscribe((data:any)=>{
      console.log(data);
      this.legal = data.total
      console.log("total data:",this.legal); 
    })
  }

  // Manufacturing
  manufacturing:any
  Manufacturing(){  
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Manufacturing').subscribe((data:any)=>{
      console.log(data);
      this.manufacturing = data.total
      console.log("total data:",this.manufacturing); 
    })
  }

  // Marketing, Advertising & Public Relations
  marketing:any
  MarketingAdvertisingPublicRelations(){  
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Marketing, Advertising & Public Relations').subscribe((data:any)=>{
      console.log(data);
      this.marketing = data.total
      console.log("total data:",this.marketing); 
    })
  }

  // Media, Entertainment & Publishing  
  media:any
  MediaEntertainmentPublishing(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Media, Entertainment & Publishing').subscribe((data:any)=>{
      console.log(data);
      this.media = data.total
      console.log("total data:",this.media); 
    })
  }

  // Non-Profit
  nonprofit:any
  NonProfit(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Non-Profit').subscribe((data:any)=>{
      console.log(data);
      this.nonprofit = data.total
      console.log("total data:",this.nonprofit); 
    })
  }

  // Retail
  retail:any
  Retail(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Retail').subscribe((data:any)=>{
      console.log(data);
      this.retail = data.total
      console.log("total data:",this.retail); 
    })
  }

  // Software, Internet & Technology
  software:any
  SoftwareInternetAndTechnology(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Software, Internet & Technology').subscribe((data:any)=>{
      console.log(data);
      this.software = data.total
      console.log("total data:",this.software); 
    })
  }

  // Telecommunications
  telecommunications:any
  Telecommunications(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Telecommunications').subscribe((data:any)=>{
      console.log(data);
      this.telecommunications = data.total
      console.log("total data:",this.telecommunications); 
    })
  }

  // Transportation
  transportation:any
  Transportation(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Transportation').subscribe((data:any)=>{
      console.log(data);
      this.transportation = data.total
      console.log("total data:",this.transportation); 
    })
  }

  // Travel, Hotel, Restaurant & Recreation
  travel:any
  TravelHotelRestaurantAndRecreation(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Travel, Hotel, Restaurant & Recreation').subscribe((data:any)=>{
      console.log(data);
      this.travel = data.total
      console.log("total data:",this.travel); 
    })
  }

  // Wholesale & Distribution
  wholesale:any
  WholesaleDistribution(){
    this.http.get('https://addwhitepaper.onrender.com/data/cat/Wholesale & Distribution').subscribe((data:any)=>{
      console.log(data);
      this.wholesale = data.total
      console.log("total data:",this.wholesale); 
    })   
  }


 

}
