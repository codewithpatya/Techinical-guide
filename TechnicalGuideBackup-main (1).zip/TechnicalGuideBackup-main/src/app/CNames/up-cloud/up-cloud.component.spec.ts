import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpCloudComponent } from './up-cloud.component';

describe('UpCloudComponent', () => {
  let component: UpCloudComponent;
  let fixture: ComponentFixture<UpCloudComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UpCloudComponent]
    });
    fixture = TestBed.createComponent(UpCloudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
