import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HCLTechComponent } from './h-cltech.component';

describe('HCLTechComponent', () => {
  let component: HCLTechComponent;
  let fixture: ComponentFixture<HCLTechComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HCLTechComponent]
    });
    fixture = TestBed.createComponent(HCLTechComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
