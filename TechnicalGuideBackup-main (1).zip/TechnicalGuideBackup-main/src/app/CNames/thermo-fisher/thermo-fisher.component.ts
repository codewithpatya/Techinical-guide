import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-thermo-fisher',
  templateUrl: './thermo-fisher.component.html',
  styleUrls: ['./thermo-fisher.component.css']
})
export class ThermoFisherComponent {

  searchText: any;

  campaignData: any ;
  dataAvailable: boolean = false;

  constructor(private http: HttpClient,private router:Router) { }

  ngOnInit(): void {
    this.fetchDataByCampaignName('Thermofisher');
  }

  fetchDataByCampaignName(campaignName: string): void {
    
    this.http.get<any[]>('https://addwhitepaper.onrender.com/data/campaign/' + encodeURIComponent(campaignName))
      .subscribe(
        data => {
          this.campaignData = data;
          console.log('Campaign data:', this.campaignData);
          this.dataAvailable = this.campaignData.length > 0; // Set the flag based on data availability
        },
        error => {
          console.error('Error fetching data:', error);
        }
      );
  }

  navigateToDetails(whitepaperHeading: string, id: number): void {
    // Replace spaces with hyphens
  const formattedHeading = whitepaperHeading.trim().replace(/\s+/g, '-');
  
  // Navigate to details component with formattedHeading and ID
  this.router.navigate(['/Resources', formattedHeading], { state: { id: id } });
  }
}
