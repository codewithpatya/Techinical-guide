import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ThermoFisherComponent } from './thermo-fisher.component';

describe('ThermoFisherComponent', () => {
  let component: ThermoFisherComponent;
  let fixture: ComponentFixture<ThermoFisherComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ThermoFisherComponent]
    });
    fixture = TestBed.createComponent(ThermoFisherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
