import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CampaignsService } from '../campaigns.service';
import { saveAs } from 'file-saver';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { ReCaptchaV3Service } from 'ngx-captcha';


@Component({
  selector: 'app-view-resource',
  templateUrl: './view-resource.component.html',
  styleUrls: ['./view-resource.component.css']
})
export class ViewResourceComponent implements OnInit {

  toastVisible = false;

  form: any;
  
  companys: any;

  inputFieldValue: string = '';

  captchaInput: string = '';  // ngModel for CAPTCHA input

  rightCode: string = '';

  captchaError: boolean = false;
  
  constructor(private recaptchaV3Service: ReCaptchaV3Service,private route: ActivatedRoute, 
    private dataService: CampaignsService,
    private http: HttpClient,private router: Router) { 
      const navigation = this.router.getCurrentNavigation();
    this.id = navigation?.extras.state ? (navigation.extras.state as { [key: string]: any })['id'] : undefined;
    }

  data: any;
  id: string | null = null;
  
  buttonText: any = 'Submit'; 
  
  ngOnInit() {

  
   
    this.onSubmit()

    if (this.id) {
      console.log('The ID is:', this.id);
      // Use this.id here
    } else {
      console.error('ID parameter is missing.');
    }

    // this.id = this.route.snapshot.paramMap.get('id');

    console.log(this.id,"the id is:");
    
    this.route.paramMap.subscribe(params => {
      const idParam = params.get('id');
      if (idParam) {
        this.id = idParam;
        this.inputFieldValue = idParam; // Direct assignment since both are strings
        this.fetchData();
      }
    });
  
    if (this.id !== null) {
      this.fetchData();
    } else {
      console.error('ID parameter is missing.');
    }
    
    this.generateCaptcha()
  }

  fetchData() {
    this.dataService.getDataById(this.id).subscribe(
      (response) => {
        this.data = response;
        console.log(this.data,"the data is:");
        if (this.data.faviconurl) {
          this.dataService.setFavicon(this.data.faviconurl);
        }
        if(this.data.campaignName){
          this.dataService.setTitle(this.data.campaignName)
        }
      },
      (error) => {
        console.error('Error fetching data:', error);
      }
    );
  }

    fileId: any;
    formData: any = {
    Name:'', 
    Email :'', 
    Phoneno:'',
    Country:'',
    PostCode:'',
    companyname:'',
    empsize:'',
    industry:'',
    jobtitle:'',
    joblevel:'',   
    captchaInput:'',
    checked: false // Initialize the checkbox value
  }; // Object to hold form data

  apiURL = 'https://downloadpaperapi.onrender.com/DownloadPaper'; // Update the port if different

  view = false;

  buttonview = true;

  onSubmit() {
    
    console.log('Submitting form with data:', this.formData);

   
     // First, validate the CAPTCHA
     if (this.formData.captchaInput.toLowerCase() !== this.rightCode) {
      this.captchaError = true;
      console.error('CAPTCHA does not match.');
      
      return;
    }

    this.captchaError = false;

    if (this.isFormDataValid()) {
     
      this.buttonText = 'Loading...';
      this.http.post(this.apiURL, this.formData).subscribe(
        (response) => {
        
          console.log('Form submitted successfully!', response);

          this.toastVisible = true;
    setTimeout(() => {
      this.toastVisible = false;
    }, 3000);
          
          // Reset form after successful submission if needed
          this.formData = {};
          // After submission, reset button text to "Submit"
           this.buttonText = 'Submit';
          this.buttonview = false;
          this.view = true;
        },
        (error) => {
        
          console.error('Error submitting form:', error);
          if (error.status === 400) {
            console.error('Bad Request: Please check the submitted data.');
          }
        }
      );
    } else {
      console.error('Invalid form data. Please correct the form and try again.');
      console.log('Please complete the CAPTCHA');
     
    } 
  }

  onDownload() {
    this.buttonview = true;
    this.view = false;
  }

  message : any;

  message1 : boolean = true;

  // Example validation function
isFormDataValid() {
  const requiredFields = ['Name', 'Email', 'Phoneno','Country','PostCode','companyname','empsize','industry','jobtitle','joblevel','captchaInput','checked'];
  // Example: Check for required fields
  for (const field of requiredFields) {
    if (!this.formData[field]) {
      console.error(`Missing required field: ${field}`);
      
     
      return false;
    }
  }
  return true;
}

loadAllData(): void {
  this.dataService.getData().subscribe((data) => {
    this.companys = data;
  });
}

// 
generateCaptcha() {
  const canvas = document.getElementById('valicode') as HTMLCanvasElement;
  const context = canvas.getContext('2d');

  if (context) {
    const canvasWidth = 150;
    const canvasHeight = 30;
    const sCode = 'A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,0,1,2,3,4,5,6,7,8,9,!,@,#,$,%,^,&,*,(,)';
    const saCode = sCode.split(',');
    const saCodeLen = saCode.length;
    const showNum = [];

    canvas.width = canvasWidth;
    canvas.height = canvasHeight;

    for (let i = 0; i <= 3; i++) {
      const sIndex = Math.floor(Math.random() * saCodeLen);
      const sDeg = (Math.random() * 30 * Math.PI) / 180;
      const cTxt = saCode[sIndex];
      showNum[i] = cTxt.toLowerCase();
      const x = 10 + i * 20;
      const y = 20 + Math.random() * 8;
      context.font = 'bold 23px 微软雅黑';
      context.translate(x, y);
      context.rotate(sDeg);
      context.fillStyle = this.randomColor();
      context.fillText(cTxt, 0, 0);
      context.rotate(-sDeg);
      context.translate(-x, -y);
    }

    for (let i = 0; i <= 5; i++) {
      context.strokeStyle = this.randomColor();
      context.beginPath();
      context.moveTo(Math.random() * canvasWidth, Math.random() * canvasHeight);
      context.lineTo(Math.random() * canvasWidth, Math.random() * canvasHeight);
      context.stroke();
    }

    for (let i = 0; i < 30; i++) {
      context.strokeStyle = this.randomColor();
      context.beginPath();
      const x = Math.random() * canvasWidth;
      const y = Math.random() * canvasHeight;
      context.moveTo(x, y);
      context.lineTo(x + 1, y + 1);
      context.stroke();
    }

    this.rightCode = showNum.join('');
  } else {
    console.error('Unable to get canvas context');
  }
}

randomColor() {
  const r = Math.floor(Math.random() * 256);
  const g = Math.floor(Math.random() * 256);
  const b = Math.floor(Math.random() * 256);
  return `rgb(${r},${g},${b})`;
}


resolved(captchaResponse: any) {
  console.log(`Resolved captcha with response: ${captchaResponse}`);
}

}




