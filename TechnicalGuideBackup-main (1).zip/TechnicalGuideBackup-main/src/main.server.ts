
export { AppServerModule } from './app/app.server.module';

import { enableProdMode } from '@angular/core';

import { environment } from '../src/environments/environment';

if (environment.production) {
  enableProdMode();
}

export { renderModule } from '@angular/platform-server';
